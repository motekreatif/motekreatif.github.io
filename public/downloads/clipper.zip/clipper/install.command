#!/bin/bash
# Double-click to install & start clipper on macOS.
cd "$(dirname "$0")" || exit 1

APP_URL="http://localhost:3060"
LOG="install.log"

clear
echo "────────────────────────────────"
echo "   Setting up clipper"
echo "────────────────────────────────"
echo

# ── Docker checks ───────────────────────────────────────────────────────────
if ! command -v docker >/dev/null 2>&1; then
  echo "  Docker Desktop isn't installed yet."
  echo "  1. Download it: https://www.docker.com/products/docker-desktop/"
  echo "  2. Install and open it (wait until it says 'running')."
  echo "  3. Double-click this file again."
  echo
  read -r -p "  Press Enter to close."
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  echo "  Docker Desktop is installed but not running."
  echo "  Please open Docker Desktop, wait until it says 'running',"
  echo "  then double-click this file again."
  echo
  read -r -p "  Press Enter to close."
  exit 1
fi

# ── First-run config ────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET=$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | xxd -p | tr -d '\n')
  tmp=$(mktemp)
  sed "s|^SESSION_SECRET=.*|SESSION_SECRET=${SECRET}|" .env > "$tmp" && mv "$tmp" .env
fi

# ── Download + start (logs hidden behind a calm spinner) ────────────────────
# Honest numbers — see the same note in install.bat. "A few hundred MB" was
# wrong by an order of magnitude and made buyers close the window mid-download.
echo "  Downloading the app… about 2 GB, one time only."
echo "  This usually takes 10-30 minutes depending on your connection."
echo "  The screen will look frozen. It is not — keep this window open."
echo

# Pull the prebuilt images, then start. No building on this machine.
{ docker compose pull && docker compose up -d; } >"$LOG" 2>&1 &
BUILD_PID=$!

spin='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
start=$(date +%s)
while kill -0 "$BUILD_PID" 2>/dev/null; do
  for c in $(echo "$spin" | grep -o .); do
    elapsed=$(( $(date +%s) - start ))
    printf "\r  %s  working… (%ss elapsed)   " "$c" "$elapsed"
    sleep 0.15
  done
done
wait "$BUILD_PID"; RC=$?
printf "\r                                             \r"

if [ "$RC" -ne 0 ]; then
  echo "  Setup didn't finish. This is usually a slow or dropped internet"
  echo "  connection during the download. Please check you're online and"
  echo "  try again."
  echo
  echo "  ── last lines of the log (for support) ──"
  tail -15 "$LOG"
  echo
  read -r -p "  Press Enter to close."
  exit 1
fi

# ── Wait until the web app answers ──────────────────────────────────────────
printf "  Almost ready"
for i in $(seq 1 60); do
  if curl -fsS "$APP_URL/api/health" >/dev/null 2>&1; then break; fi
  printf "."
  sleep 3
done
echo

echo
echo "  ✓ Done! Opening clipper in your browser…"
open "$APP_URL"
echo "  If it didn't open, go to:  $APP_URL"
echo
read -r -p "  Press Enter to close."
