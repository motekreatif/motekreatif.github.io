#!/bin/bash
# Double-click to stop clipper.
cd "$(dirname "$0")" || exit 1
docker compose down
echo "clipper stopped."
sleep 1
