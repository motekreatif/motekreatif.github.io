#!/bin/bash
# Double-click to start clipper (after it's been installed once).
cd "$(dirname "$0")" || exit 1

if ! docker info >/dev/null 2>&1; then
  echo "Please open Docker Desktop first, then run this again."
  read -r -p "Press Enter to close."
  exit 1
fi

docker compose up -d
echo "Opening http://localhost:3060 …"
sleep 2
open http://localhost:3060
