============================================================
  Clipper by Mote — quick start
============================================================

Turn any YouTube video into short vertical clips with captions,
all on your own computer. Paste a link, the AI picks the best
moments, and you download the clips. No accounts, no cloud.


STEP 1 — Install Docker Desktop (one time)
------------------------------------------------------------
Download: https://www.docker.com/products/docker-desktop/
Install it, open it, and wait until it says "running".


STEP 2 — Start Clipper
------------------------------------------------------------
Double-click the launcher in this folder:
  - macOS:    install.command
              (first time: right-click -> Open to get past the
               security prompt)
  - Windows:  install.bat

It downloads the app (a few hundred MB, one time) and opens
http://localhost:3060 in your browser. Keep the window open
while it works — it is not stuck.


STEP 3 — First-run wizard (in your browser) — 3 quick steps
------------------------------------------------------------
  1. Paste your LICENSE KEY (from your purchase email) -> Activate
  2. Set your BRAND name, logo, and color
  3. Paste your free GEMINI and GROQ API keys
     (get-key links are shown right in the wizard)

That's it — no account or password to create. Once activated,
the app is open on your computer. Paste a YouTube link and go.

Get the free keys:
  - Gemini (picks the best moments): https://aistudio.google.com/app/apikey
  - Groq (transcribes speech):       https://console.groq.com/keys
Both have free tiers.


EVERY DAY AFTER
------------------------------------------------------------
Start:  double-click start.command (mac) / start.bat (windows)
Stop:   double-click stop.command  (mac) / stop.bat  (windows)

Your finished clips appear in the "clips" folder next to this
file — open them in Finder / Explorer, no download needed.


NEED HELP?
------------------------------------------------------------
Full guide + troubleshooting:
  https://motekreatif.com/products/clipper/setup

See LICENSE.md for the commercial terms.
