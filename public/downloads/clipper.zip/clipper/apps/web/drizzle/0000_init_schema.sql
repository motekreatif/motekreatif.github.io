-- Initial Clipper schema. Idempotent so it can run on every `up -d`
-- against a database that may already have part or all of the schema.
CREATE SCHEMA IF NOT EXISTS "clipper";
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "clipper"."jobs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"youtube_url" text NOT NULL,
	"youtube_video_id" text,
	"status" text DEFAULT 'pending',
	"requested_clips" integer DEFAULT 3,
	"sheet_row" integer,
	"source" text DEFAULT 'manual',
	"highlights" jsonb DEFAULT '[]'::jsonb,
	"clip_urls" jsonb DEFAULT '[]'::jsonb,
	"repliz_schedule_ids" jsonb DEFAULT '[]'::jsonb,
	"group_id" text,
	"error_message" text,
	"created_at" timestamp DEFAULT now(),
	"started_at" timestamp,
	"completed_at" timestamp
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "clipper"."logs" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"job_id" uuid,
	"level" text,
	"step" text,
	"message" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "clipper"."settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"youtube_cookies" text,
	"cookies_updated_at" timestamp,
	"groups" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"secrets" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"clip_rules" jsonb DEFAULT '{}'::jsonb,
	"subtitle_font" text,
	"hook_font" text,
	"highlight_prompt" text,
	"google_sheet_id" text,
	"google_sheet_name" text DEFAULT 'Sheet1',
	"report_sheet_name" text DEFAULT 'Report',
	"schedule_times" jsonb DEFAULT '[]'::jsonb,
	"repliz_accounts" jsonb DEFAULT '[]'::jsonb,
	"cron_enabled" boolean DEFAULT true,
	"cron_active_days" jsonb DEFAULT '["mon","thu"]'::jsonb,
	"cron_time" text DEFAULT '03:00',
	"cron_every_days" integer DEFAULT 3,
	"cron_anchor_date" timestamp,
	"schedule_slots" jsonb DEFAULT '[{"hour":7,"minute":0},{"hour":12,"minute":30},{"hour":19,"minute":0}]'::jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
DO $$
BEGIN
	IF NOT EXISTS (
		SELECT 1 FROM pg_constraint WHERE conname = 'logs_job_id_jobs_id_fk'
	) THEN
		ALTER TABLE "clipper"."logs"
			ADD CONSTRAINT "logs_job_id_jobs_id_fk"
			FOREIGN KEY ("job_id") REFERENCES "clipper"."jobs"("id")
			ON DELETE cascade ON UPDATE no action;
	END IF;
END$$;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "logs_job_id_created_at_idx"
	ON "clipper"."logs" USING btree ("job_id","id");
