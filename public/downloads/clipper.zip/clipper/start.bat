@echo off
REM Double-click to start clipper (after install).
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Please open Docker Desktop first, then run this again.
  pause
  exit /b 1
)
docker compose up -d
echo Opening http://localhost:3060 ...
timeout /t 2 >nul
start "" http://localhost:3060
