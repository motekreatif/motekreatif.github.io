@echo off
REM Double-click to install & start clipper on Windows.
setlocal
cd /d "%~dp0"
set "APP_URL=http://localhost:3060"
set "LOG=install.log"

cls
echo --------------------------------
echo    Setting up clipper
echo --------------------------------
echo.

docker info >nul 2>&1
if errorlevel 1 (
  echo   Docker Desktop isn't running.
  echo   1. Install it: https://www.docker.com/products/docker-desktop/
  echo   2. Open it and wait until it says "running".
  echo   3. Double-click this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".env" (
  copy ".env.example" ".env" >nul
  for /f "delims=" %%S in ('powershell -NoProfile -Command "[guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')"') do set "SECRET=%%S"
  powershell -NoProfile -Command "(Get-Content .env) -replace '^SESSION_SECRET=.*', 'SESSION_SECRET=%SECRET%' | Set-Content .env"
)

echo   Downloading the app...
echo   The first time downloads a few hundred MB (one-time).
echo   Please keep this window open - it is not stuck.
echo.

docker compose pull >"%LOG%" 2>&1 && docker compose up -d >>"%LOG%" 2>&1
if errorlevel 1 (
  echo   Setup didn't finish. This is usually a slow or dropped internet
  echo   connection during the download. Please check you're online
  echo   and try again.
  echo.
  echo   -- last lines of the log ^(for support^) --
  powershell -NoProfile -Command "Get-Content '%LOG%' -Tail 15"
  echo.
  pause
  exit /b 1
)

echo   Almost ready...
for /l %%i in (1,1,60) do (
  curl -fsS "%APP_URL%/api/health" >nul 2>&1 && goto ready
  timeout /t 3 >nul
)
:ready
echo.
echo   Done! Opening clipper in your browser...
start "" "%APP_URL%"
echo   If it didn't open, go to:  %APP_URL%
echo.
pause
