@echo off
REM Double-click to stop clipper.
cd /d "%~dp0"
docker compose down
echo clipper stopped.
timeout /t 1 >nul
