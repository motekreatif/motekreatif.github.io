# Commercial License — clipper

Copyright © the seller. All rights reserved.

This software is sold, not given away. By purchasing a license key you are
granted a **non-exclusive, non-transferable license to run ONE instance on ONE
device** for your own use.

## You MAY
- Install and run the software on the single device your license key is
  activated on.
- White-label it (name, logo, colors) for your own use.
- Create and download clips for your own or your clients' content.

## You MAY NOT
- Share, resell, sublicense, rent, or redistribute the software, its source, or
  its Docker images.
- Share or reuse your license key on more than one device.
- Remove, bypass, or tamper with the license activation.

## Honest note on protection
This is a self-hosted app: it runs entirely on your machine. Device-locked
activation deters casual copying, but no self-hosted software can be made
completely uncopyable. This license is the legal agreement that governs use
regardless of technical measures.

## No warranty
The software is provided "as is", without warranty of any kind. The seller is
not liable for any damages arising from its use. You are responsible for the
API keys you configure and any costs they incur, and for complying with the
terms of the video sources you process.

## Refunds
Refunds are handled per the terms stated on the purchase page.
